from __future__ import annotations

"""Public wrapper types consumed by participant bots.

Use these classes in `on_tick(snapshot, ctx)` to read race state and issue commands.
"""

from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from typing import TYPE_CHECKING, Callable, Protocol

from hackarena3.proto.race.v1 import race_pb2, telemetry_pb2, track_pb2

if TYPE_CHECKING:
    from hackarena3.proto.race.v1.telemetry_pb2 import ParticipantSnapshot


class _OpenIntEnum(IntEnum):
    @classmethod
    def _missing_(cls, value: object) -> _OpenIntEnum:
        if not isinstance(value, int):
            raise ValueError(f"{value!r} is not a valid {cls.__name__}")
        member = int.__new__(cls, value)
        member._name_ = f"UNKNOWN_{value}"
        member._value_ = value
        return member


class GearShift(_OpenIntEnum):
    """Requested gear change for the current control packet."""

    NONE = int(race_pb2.GEAR_SHIFT_NONE)
    UPSHIFT = int(race_pb2.GEAR_SHIFT_UPSHIFT)
    DOWNSHIFT = int(race_pb2.GEAR_SHIFT_DOWNSHIFT)


class DriveGear(_OpenIntEnum):
    """Current drivetrain gear reported by telemetry."""

    REVERSE = -1
    NEUTRAL = 0
    FIRST = 1
    SECOND = 2
    THIRD = 3
    FOURTH = 4
    FIFTH = 5
    SIXTH = 6
    SEVENTH = 7
    EIGHTH = 8


class TireType(_OpenIntEnum):
    """Tire compound used by telemetry and pit strategy commands.

    `UNSPECIFIED` can appear in incoming telemetry.
    """

    UNSPECIFIED = int(telemetry_pb2.TIRE_TYPE_UNSPECIFIED)
    HARD = int(telemetry_pb2.TIRE_TYPE_HARD)
    SOFT = int(telemetry_pb2.TIRE_TYPE_SOFT)
    WET = int(telemetry_pb2.TIRE_TYPE_WET)


class GroundType(_OpenIntEnum):
    """Ground surface category around track centerline samples."""

    ASPHALT = int(track_pb2.GROUND_TYPE_ASPHALT)
    GRASS = int(track_pb2.GROUND_TYPE_GRASS)
    GRAVEL = int(track_pb2.GROUND_TYPE_GRAVEL)
    WALL = int(track_pb2.GROUND_TYPE_WALL)
    KERB = int(track_pb2.GROUND_TYPE_KERB)


class GhostModePhase(_OpenIntEnum):
    """High-level ghost mode phase for a car."""

    UNSPECIFIED = int(telemetry_pb2.GHOST_MODE_PHASE_UNSPECIFIED)
    INACTIVE = int(telemetry_pb2.GHOST_MODE_PHASE_INACTIVE)
    ACTIVE = int(telemetry_pb2.GHOST_MODE_PHASE_ACTIVE)
    PENDING_EXIT = int(telemetry_pb2.GHOST_MODE_PHASE_PENDING_EXIT)


class GhostModeBlocker(_OpenIntEnum):
    """Reason why ghost mode cannot exit yet."""

    UNSPECIFIED = int(telemetry_pb2.GHOST_MODE_BLOCKER_UNSPECIFIED)
    LAPS_REQUIREMENT_NOT_MET = int(
        telemetry_pb2.GHOST_MODE_BLOCKER_LAPS_REQUIREMENT_NOT_MET
    )
    EXIT_SPEED_NOT_MET = int(telemetry_pb2.GHOST_MODE_BLOCKER_EXIT_SPEED_NOT_MET)
    EXIT_DELAY_RUNNING = int(telemetry_pb2.GHOST_MODE_BLOCKER_EXIT_DELAY_RUNNING)
    VEHICLE_OVERLAP_ACTIVE = int(
        telemetry_pb2.GHOST_MODE_BLOCKER_VEHICLE_OVERLAP_ACTIVE
    )
    OVERLAP_EXIT_DELAY_RUNNING = int(
        telemetry_pb2.GHOST_MODE_BLOCKER_OVERLAP_EXIT_DELAY_RUNNING
    )
    IN_PIT = int(telemetry_pb2.GHOST_MODE_BLOCKER_IN_PIT)


class PitstopZoneFlag(IntFlag):
    """Bit flags describing the pitstop zone section under the car.

    Values can be combined (for example, when straddling section boundaries).
    """

    NONE = 0
    ENTER = int(telemetry_pb2.PITSTOP_ZONE_FLAG_ENTER)
    FIX = int(telemetry_pb2.PITSTOP_ZONE_FLAG_FIX)
    EXIT = int(telemetry_pb2.PITSTOP_ZONE_FLAG_EXIT)
    UNSPECIFIED = NONE


class PitEntrySource(_OpenIntEnum):
    """How the latest pit entry was triggered."""

    UNSPECIFIED = int(telemetry_pb2.PIT_ENTRY_SOURCE_UNSPECIFIED)
    BOT_DECISION = int(telemetry_pb2.PIT_ENTRY_SOURCE_BOT_DECISION)
    REQUESTED = int(telemetry_pb2.PIT_ENTRY_SOURCE_REQUESTED)
    EMERGENCY = int(telemetry_pb2.PIT_ENTRY_SOURCE_EMERGENCY)


@dataclass(frozen=True, slots=True)
class Vec3:
    """3D vector in world coordinates."""

    x: float
    y: float
    z: float


@dataclass(frozen=True, slots=True)
class CarDimensions:
    """Car footprint dimensions in meters."""

    width_m: float
    depth_m: float


@dataclass(frozen=True, slots=True)
class GroundWidth:
    """Lateral ground segment width and its surface type."""

    width_m: float
    ground_type: GroundType


@dataclass(frozen=True, slots=True)
class CenterlinePoint:
    """One static sample of the track centerline.

    Distances use meters (`*_m`), curvature is `1/m`, and angles use radians.
    """

    s_m: float
    position: Vec3
    tangent: Vec3
    normal: Vec3
    right: Vec3
    left_width_m: float
    right_width_m: float
    curvature_1pm: float
    grade_rad: float
    bank_rad: float
    max_left_width_m: float
    max_right_width_m: float
    left_grounds: tuple[GroundWidth, ...]
    right_grounds: tuple[GroundWidth, ...]


@dataclass(frozen=True, slots=True)
class PitstopLayout:
    """Static pit path split into enter/fix/exit sections."""

    enter: tuple[CenterlinePoint, ...]
    fix: tuple[CenterlinePoint, ...]
    exit: tuple[CenterlinePoint, ...]
    length_m: float


@dataclass(frozen=True, slots=True)
class TrackLayout:
    """Static track geometry for the current map.

    Access this via `ctx.track` to plan racing lines and pit strategy.
    """

    map_id: str
    lap_length_m: float
    centerline: tuple[CenterlinePoint, ...]
    pitstop: PitstopLayout


@dataclass(frozen=True, slots=True)
class Controls:
    """Driving command sent to the server.

    Expected ranges:
    - `throttle`: 0..1
    - `brake`: 0..1
    - `steering`: -1..1
    - `brake_balancer`: 0..1
    - `differential_lock`: 0..1

    Runtime clamps out-of-range numeric values before sending.
    """

    throttle: float
    brake: float
    steering: float
    gear_shift: GearShift = GearShift.NONE
    brake_balancer: float = 0.5
    differential_lock: float = 0.0


@dataclass(frozen=True, slots=True)
class Quaternion:
    """Car orientation quaternion in world space."""

    x: float
    y: float
    z: float
    w: float


@dataclass(frozen=True, slots=True)
class GhostModeState:
    """Collision state and transition details for ghost mode."""

    can_collide_now: bool
    phase: GhostModePhase
    blockers: tuple[GhostModeBlocker, ...]
    exit_delay_remaining_ms: int

    @property
    def is_ghost(self) -> bool:
        """True when collisions are currently disabled for this car."""

        return not self.can_collide_now


@dataclass(frozen=True, slots=True)
class TireWearPerWheel:
    """Per-wheel tire wear values from telemetry."""

    front_left: float
    front_right: float
    rear_left: float
    rear_right: float


@dataclass(frozen=True, slots=True)
class TireTemperaturePerWheel:
    """Per-wheel tire temperature in Celsius."""

    front_left_celsius: float
    front_right_celsius: float
    rear_left_celsius: float
    rear_right_celsius: float


@dataclass(frozen=True, slots=True)
class TireSlipPerWheel:
    """Per-wheel tire slip values from telemetry."""

    front_left: float
    front_right: float
    rear_left: float
    rear_right: float


@dataclass(frozen=True, slots=True)
class CommandCooldownState:
    """Remaining cooldowns for command-type actions, in milliseconds."""

    back_to_track_remaining_ms: int
    emergency_pitstop_remaining_ms: int


@dataclass(frozen=True, slots=True)
class CarState:
    """Dynamic telemetry state for your own car.

    Read this from `snapshot.car` inside `on_tick` to drive decisions.
    """

    car_id: int
    position: Vec3
    orientation: Quaternion
    speed_mps: float
    gear: DriveGear
    engine_rpm: float
    last_applied_client_seq: int
    pitstop_zone_flags: PitstopZoneFlag
    wheels_in_pitstop: int
    ghost_mode: GhostModeState
    tire_type: TireType
    next_pit_tire_type: TireType
    tire_wear: TireWearPerWheel
    tire_temperature_celsius: TireTemperaturePerWheel
    tire_slip: TireSlipPerWheel
    pit_request_active: bool
    pit_emergency_lock_remaining_ms: int
    last_pit_time_ms: int
    last_pit_source: PitEntrySource
    last_pit_lap: int
    command_cooldowns: CommandCooldownState

    @property
    def speed_kmh(self) -> float:
        """Current speed converted from m/s to km/h."""

        return self.speed_mps * 3.6


@dataclass(frozen=True, slots=True)
class OpponentState:
    """Lightweight opponent state visible to participant bots."""

    car_id: int
    position: Vec3
    orientation: Quaternion
    ghost_mode: GhostModeState


@dataclass(frozen=True, slots=True)
class RaceSnapshot:
    """Single participant stream snapshot passed to `on_tick`.

    Includes your car state, visible opponents, and raw protobuf payload.
    """

    tick: int
    server_time_ms: int
    car: CarState
    opponents: tuple[OpponentState, ...]
    raw: ParticipantSnapshot


@dataclass(slots=True)
class RuntimeConfig:
    """Wrapper runtime configuration.

    Usually loaded from env, but can be provided manually in tests/tools.
    """

    api_addr: str
    ha_auth_bin: str | None = None
    sandbox_id: str | None = None


def _unbound_set_controls(controls: Controls) -> None:
    _ = controls
    raise RuntimeError("BotContext is not attached to active runtime.")


def _unbound_command() -> None:
    raise RuntimeError("BotContext is not attached to active runtime.")


def _unbound_set_next_pit_tire_type(tire_type: TireType) -> None:
    _ = tire_type
    raise RuntimeError("BotContext is not attached to active runtime.")


@dataclass(frozen=True, slots=True)
class _BotContextActions:
    set_controls: Callable[[Controls], None] = _unbound_set_controls
    request_back_to_track: Callable[[], None] = _unbound_command
    request_emergency_pitstop: Callable[[], None] = _unbound_command
    set_next_pit_tire_type: Callable[[TireType], None] = _unbound_set_next_pit_tire_type


@dataclass(slots=True)
class BotContext:
    """Mutable bot context for commands and static race metadata.

    The runtime updates context fields (for example `tick`, `effective_hz`,
    `car_id`) as the stream progresses.
    """

    car_id: int
    map_id: str
    car_dimensions: CarDimensions
    requested_hz: int
    track: TrackLayout
    effective_hz: int | None
    tick: int
    _actions: _BotContextActions = field(
        default_factory=_BotContextActions,
        repr=False,
    )

    def set_controls(
        self,
        *,
        throttle: float,
        brake: float,
        steer: float,
        gear_shift: GearShift = GearShift.NONE,
        brake_balancer: float = 0.5,
        differential_lock: float = 0.0,
    ) -> None:
        """Queue driving inputs for the next outbound controls packet.

        Use this in every `on_tick` call. Ranges are the same as in `Controls`.
        """

        self._actions.set_controls(
            Controls(
                throttle=throttle,
                brake=brake,
                steering=steer,
                gear_shift=gear_shift,
                brake_balancer=brake_balancer,
                differential_lock=differential_lock,
            )
        )

    def request_back_to_track(self) -> None:
        """Request recovery back to track.

        The server may reject this command depending on race rules/cooldowns.
        """

        self._actions.request_back_to_track()

    def request_emergency_pitstop(self) -> None:
        """Request an emergency pit teleport.

        The server may reject this command depending on race rules/cooldowns.
        """

        self._actions.request_emergency_pitstop()

    def set_next_pit_tire_type(self, tire_type: TireType) -> None:
        """Set tire compound for the next pit service.

        Expected compounds are `TireType.HARD`, `TireType.SOFT`, or
        `TireType.WET`.
        """

        self._actions.set_next_pit_tire_type(tire_type)


class BotProtocol(Protocol):
    """Protocol that participant bots must implement."""

    def on_tick(self, snapshot: RaceSnapshot, ctx: BotContext) -> None: ...
